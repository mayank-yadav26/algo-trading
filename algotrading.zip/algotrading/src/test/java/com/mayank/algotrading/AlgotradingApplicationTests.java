package com.mayank.algotrading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgotradingApplicationTests {

	@Test
	void contextLoads() {
	}

}
